# CryptoNow WooCommerce Plugin (v2 — On-site)

Accept crypto on WooCommerce. Two modes:

- **On-site (embedded, default):** the pay-to address, amount and a QR code render
  directly on the WooCommerce order-pay page. The customer never leaves your store.
  Uses CryptoNow's public charge API (no API keys needed) via a server-side proxy,
  so there are no CORS issues and the wallet passphrase never reaches the browser.
- **Redirect (classic):** sends the customer to the CryptoNow hosted checkout page.

## Setup
1. Create a **Cart** checkout in your CryptoNow account and copy its link.
2. WooCommerce → Settings → Payments → CryptoNow → tick **Enabled**, choose **On-site**,
   paste the checkout link into **Checkout url**, Save.
3. Set the Callback URL in your CryptoNow **Account settings** to:
   `https://<your-site>/wp-json/crypto-now-webhook/v1`

## How it works (embedded)
`process_payment` sends the customer to the on-site order-pay page →
`POST /wp-json/cnow/v1/charge` creates the charge (`clickId = order id`) →
the page renders address + QR + amount and polls `GET /wp-json/cnow/v1/status` →
the CryptoNow callback flips the order to complete (authoritative), and the page
redirects to the thank-you page on `Done`.

Requires WordPress 5.0+, WooCommerce 5.0+, PHP 7.4+.
