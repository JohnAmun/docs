(function () {
  var el = document.getElementById('cnow-embedded');
  if (!el || !window.CNOW) return;

  var orderId = el.getAttribute('data-order');
  var built = false;
  var openNet = null;
  var selKey = null;
  var curStatus = '';
  var pollTimer = null;
  var lastWallets = [];

  var NET = {
    btc: ['Bitcoin', '#f7931a'],
    eth: ['Ethereum', '#627eea'],
    bsc: ['BNB Chain', '#f0b90b'], bnb: ['BNB Chain', '#f0b90b'],
    tron: ['Tron', '#e0022a'], trx: ['Tron', '#e0022a'],
    polygon: ['Polygon', '#8247e5'], matic: ['Polygon', '#8247e5'],
    base: ['Base', '#0052ff'],
    arbitrum: ['Arbitrum', '#28a0f0'],
    optimism: ['Optimism', '#ff0420'],
    solana: ['Solana', '#14b982'], sol: ['Solana', '#14b982'],
    avalanche: ['Avalanche', '#e84142'], avax: ['Avalanche', '#e84142'],
    fantom: ['Fantom', '#1969ff'], ftm: ['Fantom', '#1969ff'],
    moonbeam: ['Moonbeam', '#53cbc8'], glmr: ['Moonbeam', '#53cbc8'],
    ton: ['TON', '#0098ea'],
    polkadot: ['Polkadot', '#e6007a'], dot: ['Polkadot', '#e6007a'],
    kusama: ['Kusama', '#000000'], ksm: ['Kusama', '#000000'],
    blast: ['Blast', '#fcb42c']
  };
  var ORDER = ['btc','eth','bsc','bnb','tron','trx','polygon','matic','base','arbitrum','optimism','solana','sol','avalanche','avax','fantom','ftm','moonbeam','glmr','blast','ton','polkadot','dot','kusama','ksm'];

  function api(path, opts) {
    opts = opts || {};
    opts.headers = Object.assign({ 'X-WP-Nonce': CNOW.nonce, 'Content-Type': 'application/json' }, opts.headers || {});
    return fetch(CNOW.root + path, opts).then(function (r) {
      return r.json().then(function (j) { return { ok: r.ok, body: j }; });
    });
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function shortName(s) {
    return String(s || '').replace(/\s*\([^)]*\)\s*$/, '').trim() || String(s || '');
  }
  function walletKey(w) {
    return (w.nodeType || '') + '|' + (w.name || w.ticker || '');
  }
  function netMeta(node) {
    var k = (node || '').toLowerCase();
    if (NET[k]) return NET[k];
    var label = k ? k.charAt(0).toUpperCase() + k.slice(1) : 'Other';
    return [label, '#8a8a8a'];
  }
  function group(wallets) {
    var map = {};
    wallets.forEach(function (w) {
      var m = netMeta(w.nodeType);
      (map[m[0]] = map[m[0]] || { label: m[0], color: m[1], items: [] }).items.push(w);
    });
    function rank(label) {
      for (var i = 0; i < ORDER.length; i++) { if (netMeta(ORDER[i])[0] === label) return i; }
      return 999;
    }
    return Object.keys(map).map(function (k) { return map[k]; })
      .sort(function (a, b) { return rank(a.label) - rank(b.label); });
  }
  function payUri(w) {
    var node = (w.nodeType || '').toLowerCase();
    if (node === 'btc' || node.indexOf('bitcoin') !== -1) {
      return 'bitcoin:' + w.address + (w.amount ? '?amount=' + w.amount : '');
    }
    return w.address;
  }
  function copyBtn(val, label) {
    return '<button type="button" class="cnow-copy" data-copy="' + esc(val) + '">' + (label || 'Copy') + '</button>';
  }
  function statusText(s) {
    var st = (s || '').toLowerCase();
    return {
      'new': 'Waiting for payment…',
      'pending': 'Payment detected — confirming on-chain…',
      'done': 'Payment confirmed. Redirecting…',
      'expired': 'This payment window has expired. Please order again.',
      'failed': 'Payment failed. Try again or choose another method.'
    }[st] || 'Waiting for payment…';
  }
  function payHtml(w) {
    return '<div class="cnow-pay">' +
      '<div class="cnow-amt"><span class="cnow-amtlabel">Send</span> <b>' + esc(w.amount) + '</b> ' +
        esc(shortName(w.ticker || w.name)) + (w.amount ? ' ' + copyBtn(w.amount, 'Copy amount') : '') +
        (w.amountUSD ? '<div class="cnow-usd">&#8776; $' + esc(w.amountUSD) + '</div>' : '') + '</div>' +
      '<div class="cnow-addr"><code>' + esc(w.address) + '</code>' + copyBtn(w.address, 'Copy') + '</div>' +
      '<div class="cnow-qr" id="cnow-qr"></div>' +
      '<div class="cnow-netline">Network: ' + esc(netMeta(w.nodeType)[0]) + '</div>' +
    '</div>';
  }

  function buildShell(wallets, scrollRight) {
    var groups = group(wallets);
    if (openNet === null && groups.length) openNet = groups[0].label;
    var selWallet = selKey ? wallets.filter(function (x) { return walletKey(x) === selKey; })[0] : null;

    var rows = groups.map(function (g) {
      var isOpen = g.label === openNet;
      var pills = g.items.map(function (w) {
        return '<button type="button" class="cnow-pill' + (walletKey(w) === selKey ? ' is-active' : '') +
          '" data-key="' + esc(walletKey(w)) + '" data-net="' + esc(g.label) + '">' + esc(shortName(w.name || w.ticker || g.label)) + '</button>';
      }).join('');
      return '<div class="cnow-net' + (isOpen ? ' is-open' : '') + '">' +
        '<button type="button" class="cnow-netrow" data-net="' + esc(g.label) + '">' +
          '<span class="cnow-dot" style="background:' + g.color + '"></span>' +
          '<span class="cnow-netname">' + esc(g.label) + '</span>' +
          '<span class="cnow-count">' + g.items.length + '</span>' +
          '<i class="cnow-chev" aria-hidden="true"></i>' +
        '</button>' +
        '<div class="cnow-pills">' + pills + '</div>' +
      '</div>';
    }).join('');

    var right = selWallet ? payHtml(selWallet)
      : '<div class="cnow-empty">Select a network and currency to get your payment address.</div>';

    el.innerHTML =
      '<div class="cnow-box">' +
        '<div class="cnow-brand"><img src="' + esc(CNOW.icon || '') + '" alt="" /><span>Pay with crypto</span></div>' +
        '<div class="cnow-status" data-status="' + esc((curStatus || '').toLowerCase()) + '">' + esc(statusText(curStatus)) + '</div>' +
        '<div class="cnow-grid">' +
          '<div class="cnow-left"><div class="cnow-sub">Choose a network and currency, then send the exact amount.</div><div class="cnow-nets">' + rows + '</div></div>' +
          '<div class="cnow-right">' + right + '</div>' +
        '</div>' +
      '</div>';

    var qn = el.querySelector('#cnow-qr');
    if (qn && selWallet) {
      try { new QRCode(qn, { text: payUri(selWallet), width: 172, height: 172, correctLevel: QRCode.CorrectLevel.M }); } catch (e) {}
    }

    el.querySelectorAll('.cnow-netrow').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var n = btn.getAttribute('data-net');
        openNet = (openNet === n) ? null : n;
        buildShell(lastWallets);
      });
    });
    el.querySelectorAll('.cnow-pill').forEach(function (b) {
      b.addEventListener('click', function () {
        selKey = b.getAttribute('data-key');
        openNet = b.getAttribute('data-net');
        buildShell(lastWallets, true);
      });
    });
    el.querySelectorAll('.cnow-copy').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        if (navigator.clipboard) navigator.clipboard.writeText(b.getAttribute('data-copy'));
        var t = b.textContent; b.textContent = 'Copied';
        setTimeout(function () { b.textContent = t; }, 1400);
      });
    });

    built = true;

    if (scrollRight && window.innerWidth < 720) {
      var r = el.querySelector('.cnow-right');
      if (r && r.scrollIntoView) r.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  function setStatus(s) {
    curStatus = s || '';
    var node = el.querySelector('.cnow-status');
    if (!node) return;
    node.setAttribute('data-status', (s || '').toLowerCase());
    node.textContent = statusText(s);
  }

  function apply(state) {
    if (state.wallets && state.wallets.length) lastWallets = state.wallets;
    if (!built && lastWallets.length) buildShell(lastWallets);
    setStatus(state.status);
    var st = (state.status || '').toLowerCase();
    if (st === 'done') {
      if (pollTimer) clearInterval(pollTimer);
      if (state.return_url) setTimeout(function () { window.location.href = state.return_url; }, 1200);
    } else if (st === 'expired' || st === 'failed') {
      if (pollTimer) clearInterval(pollTimer);
    }
  }

  function poll() {
    api('/status?order_id=' + encodeURIComponent(orderId)).then(function (r) { if (r.ok) apply(r.body); });
  }

  el.innerHTML = '<div class="cnow-box"><div class="cnow-wait">Creating your payment…</div></div>';
  api('/charge', { method: 'POST', body: JSON.stringify({ order_id: orderId }) }).then(function (r) {
    if (!r.ok) {
      el.innerHTML = '<div class="cnow-box cnow-err">Could not start the crypto payment. Refresh or choose another method.</div>';
      return;
    }
    apply(r.body);
    pollTimer = setInterval(poll, 6000);
    setTimeout(poll, 1500);
  });
})();
