<?php

/**
 * Plugin Name: CryptoNow
 * Plugin URI: https://docs.crypto-now.io/
 * Description: Accept cryptocurrency on WooCommerce. On-site mode renders the pay-to address, amount and QR directly on your checkout (no redirect); classic hosted redirect is still available. Non-custodial, powered by CryptoNow.
 * Version: 2.6.0
 * Author: crypto-now.io
 * Author URI: https://www.crypto-now.io/
 *
 * @package WooCommerce\Admin
 */

use Cpay\Api\Modules\Webhook;
use CryptoNow\Woocommerce\PaymentStatus;
use CryptoNow\Woocommerce\BlockGateway;
use CryptoNow\Woocommerce\Rest;

defined('ABSPATH') || exit;

require_once __DIR__ . '/vendor/autoload.php';

define('CNOW_VERSION', '2.6.0');
define('CNOW_URL', plugin_dir_url(__FILE__));
define('CNOW_PATH', plugin_dir_path(__FILE__));

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

add_filter('woocommerce_payment_gateways', function ($plugins) {
    return array_merge([\CryptoNow\Woocommerce\Gateway::class], $plugins);
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $url = admin_url('admin.php?page=wc-settings&tab=checkout&section=cnow');
    return array_merge(['<a href="' . $url . '">' . __('Configure') . '</a>'], $links);
});

add_action('plugins_loaded', function () {
    return new \CryptoNow\Woocommerce\Gateway();
});

// On-site payment REST proxy (charge + status).
Rest::init();

add_filter('wc_order_statuses', function ($statuses) {
    $statuses['wc-wrong-amount'] = __('Wrong amount');
    return $statuses;
});

// Register block-based payment method
add_action('woocommerce_blocks_loaded', function () {
    if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        add_action('woocommerce_blocks_payment_method_type_registration', function ($registry) {
            $registry->register(new BlockGateway());
        });
    }
});

add_filter('woocommerce_blocks_payment_method_data', function ($data, $method) {
    if ($method instanceof BlockGateway) {
        $gateway = new \CryptoNow\Woocommerce\Gateway();
        $data['cnow_data'] = [
            'title'       => $gateway->title,
            'description' => $gateway->description,
            'supports'    => ['products', 'refunds'],
        ];
    }
    return $data;
}, 10, 2);

// Callback from CryptoNow -> flip the WooCommerce order (authoritative).
add_action('rest_api_init', function () {
    register_rest_route('crypto-now-webhook', 'v1', [
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function ($request) {
            try {
                $header = $request->get_header('X-Authorization');
                $body   = $request->get_json_params();
                if (!$header || !$body) {
                    return ['success' => false];
                }

                $webhookResult = Webhook::handleWebhook($header, $body);
                if ($webhookResult) {
                    if (
                        isset($webhookResult['outsideOrderId'])
                        && $webhookResult['typeTransaction'] == 'Replenishment'
                        && $webhookResult['systemStatus'] == 'Done'
                    ) {
                        $orderId = $webhookResult['outsideOrderId'];
                        $order = wc_get_order($orderId);

                        $order->set_status(
                            $webhookResult['chargeStatus'] != 'Done'
                                ? PaymentStatus::WC_STATUS_WRONG_AMOUNT
                                : PaymentStatus::convertToWoocommerceStatus($webhookResult['systemStatus'])
                        );
                        $order->save();

                        if (PaymentStatus::isNeedReturnStocks($webhookResult['systemStatus'])) {
                            wc_increase_stock_levels($order);
                        }

                        return ['success' => true];
                    }

                    return ['success' => false];
                }
            } catch (Exception $e) {
                return ['success' => false];
            }

            return ['success' => true];
        },
    ]);
});
