<?php

namespace CryptoNow\Woocommerce;

/**
 * Thin HTTP client for CryptoNow's PUBLIC customer-facing charge API.
 *
 * These endpoints are the same ones the hosted checkout SPA calls, keyed only
 * by the checkout identifier — NO account API keys required. All calls run
 * server-side (WP -> napi) so there is no CORS issue and the wallet passphrase
 * never reaches the browser.
 */
final class CnowApi
{
    public static function base(): string
    {
        return apply_filters('cnow_api_base', 'https://napi.crypto-now.io');
    }

    /**
     * Pull the checkout identifier (UUID) out of the configured Checkout URL,
     * e.g. https://checkouts.crypto-now.io/checkout/{identifier}
     */
    public static function identifierFromUrl($url): string
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }
        $path = parse_url($url, PHP_URL_PATH);
        if (!$path) {
            // maybe they pasted a bare identifier
            return preg_match('/^[a-z0-9\-]{8,}$/i', $url) ? $url : '';
        }
        $parts = array_values(array_filter(explode('/', $path), 'strlen'));
        return $parts ? end($parts) : '';
    }

    private static function request(string $method, string $path, array $query = [], $body = null): array
    {
        $url = self::base() . $path;
        if (!empty($query)) {
            $url .= '?' . http_build_query($query);
        }

        $args = [
            'method'  => $method,
            'timeout' => 20,
            'headers' => ['Accept' => 'application/json'],
        ];
        if ($body !== null) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($body);
        }

        $res = wp_remote_request($url, $args);

        if (is_wp_error($res)) {
            return ['ok' => false, 'code' => 0, 'data' => null, 'error' => $res->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($res);
        $raw  = wp_remote_retrieve_body($res);
        $json = json_decode($raw, true);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[cnow] ' . $method . ' ' . $url . ' -> ' . $code . ' ' . substr((string) $raw, 0, 2000));
        }

        return [
            'ok'   => ($code >= 200 && $code < 300),
            'code' => $code,
            'data' => $json,
            'raw'  => $raw,
        ];
    }

    /**
     * POST /api/checkout-client/{identifier}/charge
     * Cart charge: pass amount + fiatCurrency. Returns { data: { id } }.
     */
    public static function createCharge(string $identifier, array $args): array
    {
        $query = array_filter([
            'clickId'      => $args['clickId'] ?? null,
            'amount'       => $args['amount'] ?? null,
            'fiatCurrency' => $args['fiatCurrency'] ?? null,
        ], static function ($v) {
            return $v !== null && $v !== '';
        });

        return self::request(
            'POST',
            '/api/checkout-client/' . rawurlencode($identifier) . '/charge',
            $query
        );
    }

    /**
     * GET /api/checkout-client/{chargeId}/charge -> status + wallets + amounts.
     */
    public static function getCharge(string $chargeId): array
    {
        return self::request('GET', '/api/checkout-client/' . rawurlencode($chargeId) . '/charge');
    }

    /**
     * Normalise the charge response into a stable shape for the front-end.
     * Defensive against field-path drift between API versions.
     */
    public static function normalizeCharge($response): array
    {
        $d = $response['data'] ?? $response ?? [];

        $wallets = [];
        foreach (($d['wallets'] ?? []) as $w) {
            if (!is_array($w) || empty($w['address'])) {
                continue; // some endpoints return wallet-id strings; skip those
            }
            $cur = $w['currency'] ?? [];
            $amount = '';
            if (isset($w['amountCurrency'])) {
                $amount = (string) $w['amountCurrency'];
            } elseif (isset($w['amount']['value'])) {
                $amount = (string) $w['amount']['value'];
            }
            $wallets[] = [
                'address'   => (string) ($w['address'] ?? ''),
                'name'      => (string) ($cur['title'] ?? $cur['name'] ?? ''),
                'ticker'    => (string) ($cur['name'] ?? ''),
                'nodeType'  => (string) ($cur['nodeType'] ?? ''),
                'amount'    => $amount,
                'amountUSD' => isset($w['amount']['usd']) ? (string) $w['amount']['usd'] : '',
                'decimals'  => $cur['decimals'] ?? null,
                'contract'  => (string) ($cur['contractAddress'] ?? ''),
            ];
        }

        return [
            'status'  => (string) ($d['systemStatus'] ?? $d['status'] ?? ''),
            'expires' => (string) ($d['expiredDate'] ?? ''),
            'orderId' => (string) ($d['outsideOrderId'] ?? ''),
            'wallets' => $wallets,
        ];
    }
}
