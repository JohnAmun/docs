const settings = window.wc.wcSettings.getSetting( 'cnow_data', {} );
const label = window.wp.htmlEntities.decodeEntities( settings.title ) || window.wp.i18n.__( 'cnow' );
const Content = () => {
    return window.wp.htmlEntities.decodeEntities( settings.description || '' );
};
const CNOW_Block_Gateway = {
    name: 'cnow',
    label: label,
    content: Object( window.wp.element.createElement )( Content, null ),
    edit: Object( window.wp.element.createElement )( Content, null ),
    canMakePayment: () => true,
    ariaLabel: label,
    supports:
    {
        features: settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod( CNOW_Block_Gateway );

