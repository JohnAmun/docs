<?php

namespace CryptoNow\Woocommerce;

/**
 * Server-side proxy so the browser never talks to napi directly
 * (no CORS, passphrase stays server-side). Public routes — the underlying
 * charge API is public and everything is scoped to a real WC order.
 */
final class Rest
{
    const NS = 'cnow/v1';

    public static function init(): void
    {
        add_action('rest_api_init', [__CLASS__, 'routes']);
    }

    public static function routes(): void
    {
        register_rest_route(self::NS, '/charge', [
            'methods'             => 'POST',
            'permission_callback' => '__return_true',
            'callback'            => [__CLASS__, 'charge'],
            'args'                => ['order_id' => ['required' => true]],
        ]);

        register_rest_route(self::NS, '/status', [
            'methods'             => 'GET',
            'permission_callback' => '__return_true',
            'callback'            => [__CLASS__, 'status'],
            'args'                => ['order_id' => ['required' => true]],
        ]);
    }

    private static function settings(): array
    {
        $s = get_option('woocommerce_cnow_settings', []);
        return is_array($s) ? $s : [];
    }

    private static function mapFiat(string $wcCurrency): string
    {
        // Charge endpoint accepts: USD, AUD, BRL, EUR, GBP, NGN, TRY, UAH, RUB, USDT, USDC
        $allowed = ['USD', 'AUD', 'BRL', 'EUR', 'GBP', 'NGN', 'TRY', 'UAH', 'RUB', 'USDT', 'USDC'];
        $c = strtoupper($wcCurrency);
        return in_array($c, $allowed, true) ? $c : 'USD';
    }

    public static function charge($request)
    {
        $orderId = absint($request->get_param('order_id'));
        $order = $orderId ? wc_get_order($orderId) : null;
        if (!$order) {
            return new \WP_REST_Response(['error' => 'order_not_found'], 404);
        }

        $chargeId = $order->get_meta('_cnow_charge_id');

        if (!$chargeId) {
            $identifier = CnowApi::identifierFromUrl(self::settings()['checkout_url'] ?? '');
            if (!$identifier) {
                return new \WP_REST_Response(['error' => 'no_checkout_url'], 400);
            }

            $res = CnowApi::createCharge($identifier, [
                'clickId'      => (string) $orderId,
                'amount'       => (string) $order->get_total(),
                'fiatCurrency' => self::mapFiat($order->get_currency()),
            ]);

            if (empty($res['ok'])) {
                return new \WP_REST_Response(
                    ['error' => 'charge_failed', 'detail' => $res['data'] ?? ($res['error'] ?? null)],
                    502
                );
            }

            $chargeId = $res['data']['data']['id'] ?? ($res['data']['id'] ?? '');
            if (!$chargeId) {
                return new \WP_REST_Response(['error' => 'no_charge_id', 'detail' => $res['data']], 502);
            }

            $order->update_meta_data('_cnow_charge_id', $chargeId);
            $order->save();
        }

        return self::payload($order, $chargeId);
    }

    public static function status($request)
    {
        $orderId = absint($request->get_param('order_id'));
        $order = $orderId ? wc_get_order($orderId) : null;
        if (!$order) {
            return new \WP_REST_Response(['error' => 'order_not_found'], 404);
        }

        $chargeId = $order->get_meta('_cnow_charge_id');
        if (!$chargeId) {
            return new \WP_REST_Response(['error' => 'no_charge'], 404);
        }

        return self::payload($order, $chargeId);
    }

    private static function payload($order, string $chargeId)
    {
        $res = CnowApi::getCharge($chargeId);
        if (empty($res['ok'])) {
            return new \WP_REST_Response(
                ['error' => 'status_failed', 'detail' => $res['data'] ?? ($res['error'] ?? null)],
                502
            );
        }

        $norm = CnowApi::normalizeCharge($res['data']);
        $norm['return_url'] = $order->get_checkout_order_received_url();

        return new \WP_REST_Response($norm, 200);
    }
}
