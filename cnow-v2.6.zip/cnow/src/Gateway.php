<?php

namespace CryptoNow\Woocommerce;

use WC_Payment_Gateway;

final class Gateway extends WC_Payment_Gateway
{
    public $id = 'cnow';
    public $has_fields = false;
    public $title = 'Pay with CryptoNow';
    public $method_title = 'CryptoNow';
    public $method_description = '';
    public $checkout_url;
    private $logo_theme;

    public function __construct()
    {
        $this->title = $this->get_option('method_title') ?: $this->title;
        $this->method_description = "
        <p>Accept crypto on your WooCommerce checkout. In <b>On-site</b> mode the customer pays without leaving your store — the address, amount and QR render right on the order page.</p>
        <p>1) Create an account at <a href='https://app.crypto-now.io/sign-up'>crypto-now.io</a>.</p>
        <p>2) Create a <b>Cart</b> checkout and copy its link.</p>
        <p>3) Paste the link into <b>Checkout url</b> below and tick <b>Enabled</b>.</p>
        <p>4) Set the callback url in your CryptoNow Account settings to: <code>" . esc_html(home_url('/wp-json/crypto-now-webhook/v1')) . "</code></p>
        ";
        $this->description = $this->get_option('description');
        $this->form_fields = $this->adminFields();
        $this->init_settings();

        $default_icon = defined('CNOW_URL') ? CNOW_URL . 'assets/cnow-icon.png' : plugin_dir_url(dirname(__FILE__)) . 'assets/cnow-icon.png';
        $this->icon = esc_url(get_option('cnow_method_image')) ?: esc_url($default_icon);

        add_action("woocommerce_update_options_payment_gateways_{$this->id}", [$this, 'process_admin_options']);
        add_action("woocommerce_receipt_{$this->id}", [$this, 'receipt_page']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function adminFields()
    {
        return [
            'enabled' => [
                'title'   => __('Enabled'),
                'type'    => 'checkbox',
                'default' => 'no',
            ],
            'mode' => [
                'title'       => 'Payment mode',
                'type'        => 'select',
                'default'     => 'embedded',
                'options'     => [
                    'embedded' => 'On-site (address + QR on your checkout) — recommended',
                    'redirect' => 'Redirect (send customer to CryptoNow hosted page)',
                ],
                'description' => 'On-site keeps the customer on your store. Redirect is the classic hosted flow.',
            ],
            'checkout_url' => [
                'title' => 'Checkout url<p><font size="1">Create a <b>Cart</b> checkout in your CryptoNow account and paste its link here.</font></p>',
                'type'  => 'text',
            ],
            'method_title' => [
                'title'   => 'Method title<p><font size="1">Payment method name shown at checkout.</font></p>',
                'type'    => 'text',
                'default' => 'Pay with CryptoNow',
            ],
            'description' => [
                'title'   => 'Method description<p><font size="1">Shown next to the method at checkout.</font></p>',
                'type'    => 'text',
                'default' => 'Pay with cryptocurrency',
            ],
            'method_image' => [
                'title'       => 'Method Image',
                'type'        => 'file',
                'description' => 'Upload an icon for the payment method',
            ],
        ];
    }

    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);
        $mode  = $this->get_option('mode', 'embedded');

        if ($mode === 'redirect') {
            $order->update_status(PaymentStatus::WC_STATUS_PENDING);
            $order->save();
            wc_reduce_stock_levels($order_id);
            WC()->cart->empty_cart();

            $checkout_url = sprintf(
                '%s?clickId=%s&amount=%s&fiatCurrency=%s&returnUrl=%s',
                $this->settings['checkout_url'],
                (string) $order_id,
                (string) $order->get_total(),
                (string) $order->get_currency(),
                get_site_url()
            );

            return ['result' => 'success', 'redirect' => $checkout_url];
        }

        // On-site (embedded): keep the customer on the order-pay page.
        $order->update_status(PaymentStatus::WC_STATUS_PENDING, __('Awaiting crypto payment.', 'cnow'));
        wc_reduce_stock_levels($order_id);
        WC()->cart->empty_cart();

        return ['result' => 'success', 'redirect' => $order->get_checkout_payment_url(true)];
    }

    /**
     * Rendered on the WooCommerce order-pay page for embedded mode.
     */
    public function receipt_page($order_id)
    {
        if ($this->get_option('mode', 'embedded') !== 'embedded') {
            return;
        }
        echo '<div class="cnow-embedded" id="cnow-embedded" data-order="' . esc_attr($order_id) . '"></div>';
    }

    public function enqueue_assets()
    {
        if ($this->get_option('mode', 'embedded') !== 'embedded') {
            return;
        }
        if (!function_exists('is_wc_endpoint_url') || !is_wc_endpoint_url('order-pay')) {
            return;
        }

        $ver = defined('CNOW_VERSION') ? CNOW_VERSION : '2.0.0';
        $base = defined('CNOW_URL') ? CNOW_URL : plugin_dir_url(dirname(__FILE__));

        wp_enqueue_style('cnow-checkout', $base . 'assets/checkout.css', [], $ver);
        wp_enqueue_script('cnow-qrcode', $base . 'assets/qrcode.min.js', [], $ver, true);
        wp_enqueue_script('cnow-checkout', $base . 'assets/checkout.js', ['cnow-qrcode'], $ver, true);
        wp_localize_script('cnow-checkout', 'CNOW', [
            'root'  => esc_url_raw(rest_url(Rest::NS)),
            'nonce' => wp_create_nonce('wp_rest'),
            'icon'  => esc_url_raw($this->icon),
        ]);
    }

    public function process_admin_options()
    {
        parent::process_admin_options();

        $uploaded = $_FILES['woocommerce_cnow_method_image'] ?? null;
        if ($uploaded && !empty($uploaded['tmp_name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            $movefile = wp_handle_upload($uploaded, ['test_form' => false]);
            if ($movefile && !isset($movefile['error'])) {
                update_option('cnow_method_image', $movefile['url']);
            }
        }
    }

    public function admin_options()
    {
        $image_url = get_option('cnow_method_image');
        echo '<h2>' . esc_html($this->method_title) . '</h2>';
        echo '<div>' . $this->method_description . '</div>';
        if (!empty($image_url)) {
            echo '<h3>' . __('Image Preview', 'woocommerce') . '</h3>';
            echo '<img src="' . esc_url($image_url) . '" alt="Method Image" style="max-width:200px;height:auto;" /><br />';
        }
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';
    }

    public function is_available()
    {
        if ($this->get_option('enabled') !== 'yes') {
            return false;
        }
        if (empty($this->get_option('checkout_url'))) {
            return false;
        }
        return true;
    }
}
